package com.example.modul6;

public class Konfigurasi {
    //Dibawah ini merupakan Pengalamatan dimana Lokasi Skrip CRUD PHP disimpan
    //Pada tutorial Kali ini, karena kita membuat localhost maka alamatnya tertuju ke IP komputer
    //dimana File PHP tersebut berada
    //PENTING! JANGAN LUPA GANTI IP SESUAI DENGAN IP KOMPUTER DIMANA DATA PHP BERADA
    public static final String URL_ADD="http://192.168.43.131/mobile/insert.php";
    public static final String URL_GET_ALL = "http://192.168.43.131/mobile/read.php";;
    public static final String URL_GET_EMP = "http://192.168.43.131/mobile/select.php";;
    public static final String URL_UPDATE_EMP = "http://192.168.43.131/mobile/update.php";;
    public static final String URL_DELETE_EMP = "http://192.168.43.131/mobile/delete.php";

    //Dibawah ini merupakan Kunci yang akan digunakan untuk mengirim permintaan ke Skrip PHP
    public static final String KEY_MHS_ID = "id";
    public static final String KEY_MHS_NAMA = "nama";
    public static final String KEY_MHS_POSISI = "jurusan"; //desg itu variabel untuk jurusan
    public static final String KEY_MHS_GAJIH = "email"; //salary itu variabel untuk email

    //JSON Tags
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_JURUSAN = "jurusan";
    public static final String TAG_EMAIL = "email";

    //ID mhs
    //emp itu singkatan dari Employee
    public static final String MHS_ID = "mhs_id";
}

